#include <iostream>
#include <fstream>
#include <queue>
std::ifstream fin("bleach.in");
std::ofstream fout("bleach.out");
int main() {
    long long n,k,p_curr=0, p_init=0;
    std::priority_queue<long long, std::vector<long long>, std::greater<>> pq;
    fin>>n>>k;
    for(long long i=1;i<=std::min(n,k+1);i++)
    {
        long long temp;
        fin>>temp;
        pq.push(temp);
    }
    long long index=std::min(n,k+1);
    while(!pq.empty())
    {
        long long curr=pq.top();
        pq.pop();
        if(p_curr<curr)
        {
            p_init+=curr-p_curr;
            p_curr=2*curr;
        }
        else
            p_curr+=curr;
        if(index<n)
        {
            long long temp;
            fin>>temp;
            pq.push(temp);
            index++;
        }
    }
    fout<<p_init;
    return 0;
}
