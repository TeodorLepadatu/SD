#include <iostream>
#include <fstream>
#include <vector>
#include <climits>
#include <cstdlib>

std::ifstream fin("pikachu.in");
std::ofstream fout("pikachu.out");
long long n,k,mx;
std::vector<long long> h;
long long magie(long long height)
{
    long long operatii = 0;
    long long mn=LLONG_MAX;
    for(long long i=0;i<n;i++)
    {
        operatii+=std::abs(h[i]-height);
        if(i>=k-1)
        {
            if(operatii<mn)
                mn=operatii;
            operatii-=std::abs(h[i-k+1]-height);
        }
    }
    return mn;
}
int main() {
    fin>>n>>k;
    for(long long i=0;i<n;i++)
    {
        long long temp;
        fin>>temp;
        h.push_back(temp);
        mx=std::max(temp,mx);
    }

    long long start=1, end=mx;
    while (start <= end) {
        long long mid = (start + end) / 2;
        if (magie(mid-1) > magie(mid + 1))
            start = mid + 1;
        else
            end = mid - 1;
    }

    fout<<std::min(magie(start), magie(start - 1));
    return 0;
}