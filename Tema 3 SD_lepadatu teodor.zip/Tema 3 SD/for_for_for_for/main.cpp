#include <iostream>
#include <queue>

typedef unsigned long long ull;

/// functie care pune bitii in oglinda
unsigned int reverse(unsigned int x)
{
    unsigned int y=0;
    for(int i=1; i<=32; i++)
    {
        y= y*2 + (x%2);
        x/=2;
    }
    return y;
}

unsigned int flip_bits(unsigned int x){
    unsigned int y=0;
    for(int i=0; i<32; i++)
    {
        y=(y<<1)|(1-(x&1));
        x>>=1;
    }
    return y;
}
class Trie {
private:
    Trie *zero;
    Trie *one;
    unsigned int val;
public:
    Trie() : zero{nullptr}, one{nullptr}, val{0} {}

    unsigned int cauta(unsigned int x, int depth = 32) ///cauta cel mai apropiat nr de complement
    {
        if(depth == 0)
            return val;
        if(x%2 == 1) {
            if (this->one != nullptr)
            {
                return this->one->cauta(x/2 , depth -1);
            }
            else if(this->zero != nullptr)
                return this->zero->cauta(x/2,depth -1);
        }
        else
        {
            if (this->zero != nullptr)
            {
                return this->zero->cauta(x/2 , depth -1);
            }
            else if(this->one != nullptr)
                return this->one-> cauta(x/2,depth -1);
        }

    }
    void insert(unsigned int x, unsigned int valoare, int depth = 32)
    {
        if(depth == 0) {
            val = valoare;
            return;
        }
        if(x%2 == 1)
        {
            if(this->one == nullptr)
            {
                this->one = new Trie();
            }
            this->one->insert(x/2, valoare, depth-1);
        }
        else
        {
            if(this->zero == nullptr)
            {
                this->zero = new Trie();
            }
            this->zero->insert(x/2, valoare, depth-1);
        }
    }
};

int main() {
    unsigned int n;
    std::vector<unsigned int> v;

    std::cin >> n;
    v.push_back(0);
    for(int i = 1; i <= n; i++) {
        unsigned int x;
        std::cin >> x;
        v.push_back(x);
    }

    unsigned int maxval[n + 1];
    unsigned int max1 = std::max(v[n], v[n-1]);
    unsigned int max2 = v[n] ^ v[n-1] ^ max1;
    maxval[n-1] = max1 + max2;
    for(unsigned i = n-2; i>=2 ; i--)
    {
        if(v[i] > max1)
        {
            max2=max1;
            max1 = v[i];
        }
        else
        {
            if( v[i]> max2)
                max2 = v[i];
        }
        maxval[i] = max1 + max2;
    }
    Trie* trie = new Trie();
    trie->insert(reverse(v[1]),v[1]);
    unsigned long long max_ = 0;
    for(unsigned int j=2;j<=n-2;j++)
    {
        unsigned int vi=trie->cauta(flip_bits(v[j]));
        unsigned int vj=v[j];
        unsigned int vkl=maxval[j+1];
        unsigned long long candidat=(ull)(vi^vj);
        candidat*= vkl;

        max_ = std::max(max_, candidat);

        trie->insert(reverse(v[j]),v[j]);
    }

    std::cout << max_;

    delete trie;

    return 0;
}
