#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <tuple>

int main() {
    std::ifstream infile("proc2.in");
    std::ofstream outfile("proc2.out");

    int N, M;
    infile >> N >> M;

    std::vector<std::pair<int, int>> tasks(M);
    for (int i = 0; i < M; ++i) {
        infile >> tasks[i].first >> tasks[i].second;
    }

    // Priority queue to manage available processors (min-heap)
    std::priority_queue<int, std::vector<int>, std::greater<int>> availableProcessors;
    for (int i = 0; i < N; ++i) {
        availableProcessors.push(i + 1);
    }

    // Priority queue to manage the end times of processors (min-heap)
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> busyProcessors;

    std::vector<int> result(M);

    for (int i = 0; i < M; ++i) {
        int startTime = tasks[i].first;
        int duration = tasks[i].second;

        // Release processors that have finished their tasks by the start time of the current task
        while (!busyProcessors.empty() && busyProcessors.top().first <= startTime) {
            availableProcessors.push(busyProcessors.top().second);
            busyProcessors.pop();
        }

        // Get the processor with the smallest index
        int processor = availableProcessors.top();
        availableProcessors.pop();

        // Assign the task to the processor
        result[i] = processor;

        // Update the time when this processor will be free
        busyProcessors.push({startTime + duration, processor});
    }

    for (int i = 0; i < M; ++i) {
        outfile << result[i] << std::endl;
    }

    infile.close();
    outfile.close();

    return 0;
}
