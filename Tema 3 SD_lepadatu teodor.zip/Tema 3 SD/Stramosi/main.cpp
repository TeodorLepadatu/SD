#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream fin("stramosi.in");
ofstream fout("stramosi.out");

vector<vector<int>> dp(34, vector<int>(250001, 0));
int main() {

    int n,m;
    fin>>n>>m;
    for(int i = 1; i <= n; i++) {
        fin >> dp[0][i];
    }
    for(int i=1;i<34;i++)
        for(int j=1;j<=n;j++)
            dp[i][j]=dp[i-1][dp[i-1][j]];
    for(int i=1;i<=m;i++) {
        int q, p;
        fin >> q >> p;
        int nivel = 0;
        int stramos = q;
        while (p != 0){
            if (p % 2 == 1)
                stramos = dp[nivel][stramos];
            p /= 2;
            nivel++;
        }
        fout<<stramos<<"\n";
    }
    return 0;
}
