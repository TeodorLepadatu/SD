#include <iostream>
#include <vector>
unsigned long long sp[100010];
unsigned long long r[17][100010];
unsigned long long E[100010];
int main () {
    unsigned long long n, m, i, j, st, dr, p, e, len;
    std::cin>>n;
    std::cin>>r[0][1];
    sp[1]=r[0][1];
    for (i=2;i<=n;i++) {
        std::cin >> r[0][i];
        sp[i]=r[0][i]+sp[i-1];
    }
    for (p=1; (1<<p) <= n; p++)
        for (i=1;i<=n;i++) {
            r[p][i] = r[p-1][i];
            j = i + (1<<(p-1));
            if (j <= n && r[p][i] > r[p-1][j])
                r[p][i] = r[p-1][j];
        }
    E[1] = 0;
    for (i=2;i<=n;i++)
        E[i] = 1 + E[i/2];
    std::cin>>m;
    for (i=1;i<=m;i++) {
        std::cin>>st>>dr;
        e = E[dr-st+1];
        len = (1<<e);
        unsigned long long mn=std::min(r[e][st], r[e][dr-len+1]);
        unsigned long long sum=sp[dr]-sp[st-1];
        if(sum==(mn+mn+dr-st)*(dr-st+1)/2)
            std::cout<<1;
        else
            std::cout<<0;
    }
    return 0;
}