#include <iostream>
#include <vector>

using namespace std;

int main()
{
    unsigned long long cnt = 0;     ///cantitate
    int N;
    cin>>N;
    vector<int> nr(N);
    vector<int> min_left(N);

    for(int i = 0; i < N; i++)
    {
        cin>>nr[i];
        if(i == 0)
            min_left[i] = i;
        else if(nr[i - 1] < nr[i])
            min_left[i] = i;
        else
        {
            int index = min_left[i - 1];
            while(index > 0 && nr[index] >= nr[i])
            {
                if(nr[index] >= nr[i])
                    index = min_left[index] - 1;
                else
                    break;
            }
            if(nr[index] < nr[i])
                index++;
            if(index < 0)
                index = 0;
            min_left[i] = index;
        }
    }

    int l = 0;
    while(l < N)
    {
        cnt += l - min_left[l];
        for(int i = 1; i < l - min_left[l]; i++)
        {
            if(l + i < N && min_left[l + i] > l)
            {
                cnt += l - min_left[l] - i;
            }
            else
                break;
        }
        l++;
    }

    cout<<cnt;
}