#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>

std::ifstream fin("plantatie.in");
std::ofstream fout("plantatie.out");
std::vector<std::vector<std::vector<int>>> a(502, std::vector<std::vector<int>>(502, std::vector<int>(10, 0)));

void RMQ(int n) {
    for (int k = 1; (1 << k) <= n; k++) {
        for (int i = 1; i + (1 << k) - 1 <= n; i++) {
            for (int j = 1; j + (1 << k) - 1 <= n; j++) {
                int next_k = k - 1;
                a[i][j][k] = std::max({a[i][j][next_k],a[i + (1 << next_k)][j][next_k],a[i][j + (1 << next_k)][next_k],a[i + (1 << next_k)][j + (1 << next_k)][next_k]});
            }
        }
    }
}

int query(int x, int y, int l) {
    int k = log2(l);
    return std::max({a[x][y][k],a[x + l - (1 << k)][y][k],a[x][y + l - (1 << k)][k],a[x + l - (1 << k)][y + l - (1 << k)][k]});
}

int main() {
    int n, m;
    fin >> n >> m;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fin >> a[i][j][0];
        }
    }

    RMQ(n);

    for (int i = 0; i < m; i++) {
        int x, y, l;
        fin >> x >> y >> l;
        fout << query(x, y, l) << std::endl;
    }

    return 0;
}
