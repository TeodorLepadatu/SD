#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
std::ifstream fin("timbre.in");
std::ofstream fout("timbre.out");
bool sortbyfirst(std::pair<int, int> a, std::pair<int, int> b)
{
    return a.first<=b.first;
}
int main() {
    int n, m, k;
    fin>>n>>m>>k;
    std::vector<std::pair<int,int>> v;
    for(int i=1;i<=m;i++)
    {
        int marg, pret;
        fin>>marg>>pret;
        v.push_back(std::make_pair(marg, pret));
    }
    std::sort(v.begin(), v.end(), sortbyfirst);
    std::priority_queue<int, std::vector<int>,std::greater<> >pq;
    int sol=0;
    for(int i=n-1;i>=0;i-=k)
    {
        while(!v.empty() && v.back().first >= i){
            pq.push(v.back().second);
            v.pop_back();
        }
        sol += pq.top();
        pq.pop();
    }
    fout<<sol;
    return 0;
}
