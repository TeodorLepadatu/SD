#include <iostream>
#include <vector>
#include <algorithm>
bool sortbyfirst(const std::pair<long long, long long>& a, const std::pair<long long, long long>& b)
{
    return a.first < b.first;
}
int main() {
    long long n;
    std::cin>>n;
    std::vector<std::pair<long long,long long>> v;
    std::vector<long long> f;
    long long nr0=n;
    for(long long i=1;i<=n;i++)
    {
        long long temp;
        std::cin>>temp;
        v.push_back(std::make_pair(temp,i));
        std::cin>>temp;
        v.push_back(std::make_pair(temp,i));
        f.push_back(0);
    }
    std::sort(v.begin(),v.end(), sortbyfirst);
    long long i=0,j=0;
    long long dif=2147483647;
    while(j-i<=n-1)
    {
        if(f[v[j].second-1]==0)
            nr0--;
        f[v[j].second-1]++;
        j++;
        if(j-i==n)
        {
            j--;
            break;
        }
    }
    while(j<v.size())
    {
        while(j-i<n-1)
        {
            if(f[v[j].second-1]==0)
                nr0--;
            f[v[j].second-1]++;
            j++;
            if(j-i==n)
            {
                j--;
                break;
            }
        }
        if(nr0==0) {
            dif = std::min(dif, v[j].first - v[i].first);
        }
        j++;
        if(j==v.size())
            break;
        if(f[v[j].second-1]==0)
            nr0--;
        f[v[j].second-1]++;
        while(f[v[i].second-1]>1)
        {
            f[v[i].second-1]--;
            i++;
        }
        if(j==v.size())
            break;
    }
    std::cout<<dif;
    return 0;
}
