#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <cmath>
#include <fstream>
#define MOD 1000000007

using namespace std;

class SegmentTree {
private:
    vector<int> tree;
    int n;

    void build(const vector<int>& data, int node, int start, int end) {
        if (start == end) {
            tree[node] = data[start];
        } else {
            int mid = (start + end) / 2;
            build(data, 2 * node, start, mid);
            build(data, 2 * node + 1, mid + 1, end);
            tree[node] = max(tree[2 * node], tree[2 * node + 1]);
        }
    }

    int query(int node, int start, int end, int l, int r) {
        if (r < start || end < l) {
            return INT_MIN;
        }
        if (l <= start && end <= r) {
            return tree[node];
        }
        int mid = (start + end) / 2;
        int leftQuery = query(2 * node, start, mid, l, r);
        int rightQuery = query(2 * node + 1, mid + 1, end, l, r);
        return max(leftQuery, rightQuery);
    }

public:
    SegmentTree(const vector<int>& data) {
        n = data.size();
        tree.resize(4 * n);
        build(data, 1, 0, n - 1);
    }

    int rangeMaxQuery(int l, int r) {
        return query(1, 0, n - 1, l, r);
    }
};

int main() {

    int n;
    vector<int> sequence;

    cin>>n;

    for(int i = 0 ; i < n ; i++){
        int a;
        cin >> a;
        sequence.push_back(a);
    }

    SegmentTree segTree(sequence);

    int q;
    cin >> q;

    vector<int> power_of_2;
    int power = 1;

    for(int i = 0 ; i <= n; i++){
        power_of_2.push_back(power);
        power = (power << 1) % MOD;
    }

    for (int i = 0 ; i < q; i++) {
        int l;
        int r;
        cin >> l >> r;
        l--;
        r--;
        long long result = segTree.rangeMaxQuery(l, r);
        cout << (result * power_of_2[r-l]) % MOD<< '\n';
    }
    return 0;
}
