#include<bits/stdc++.h>
int main(){
    std::ifstream fin("kami.in");
    std::ofstream fout("kami.out");
    int n;
    std::vector<long long> v;
    int nr_op;
    fin >> n;
    for(int i = 0 ; i < n ; i++){
        int a;
        fin >> a;
        v.push_back(a);
    }
    fin >> nr_op;
    for(int i = 0; i < nr_op; i++){
        int t;
        fin >> t;
        if(t == 0){
            int pos, val;
            fin >> pos >> val;
            v[pos - 1] = val;
        }else {
            int start;
            fin >> start;
            start--; ///indentarea este de la 0
            bool ok = false;
            long long cnt = v[start];
            while (start != 0) {
                if (cnt <= v[start - 1]) {
                    break;
                }
                cnt += v[start - 1];
                if(cnt > 1000000000){       ///daca a trecut de int, bafta, ca e 10^9 adica maximul din vector
                    fout << 0 << '\n';
                    ok = true;
                    break;
                }
                start--;
            }
            if(!ok) {
                fout << start << '\n';
            }
        }
    }
    return 0;
}