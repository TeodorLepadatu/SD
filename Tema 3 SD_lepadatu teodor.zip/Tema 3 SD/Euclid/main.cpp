#include <iostream>
#include <fstream>
std::ifstream fin("euclid.in");
std::ofstream fout("euclid.out");
long long cmmdc(long long m, long long n)
{
    while(m != 0)
    {
        long long r = n % m;
        n = m;
        m = r;
    }
    return n;
}
int main() {
    int t;
    fin>>t;
    for(int i=1;i<=t;i++)
    {
        int m,n,h,w;
        fin>>m>>n>>h>>w;
        long long a[402][402];
        for(int x=1;x<=m;x++)
            for(int y=1;y<=n;y++)
                fin>>a[x][y];
        long long rez=1;
        for(int i=1;i<=m-h+1;i++)
        {
            for(int j=1;j<=n-w+1;j++)
            {
                long long gcd=a[i][j];
                for(int k=i;k<i+h && gcd>rez;k++)
                {
                    for(int l=j;l<j+w && gcd>rez;l++)
                    {
                        gcd=cmmdc(gcd, a[k][l]);
                    }
                }
                rez=std::max(rez, gcd);
            }
        }
        fout<<"Case #"<<i<<": "<<rez<<std::endl;
    }
    return 0;
}
